Thank you for supporting my free asset collection!

Here are the Terms of Use for any files in this collection:

You are allowed to:

   - use all of the assets in this collection
   - use the assets in non-commercial or commercial projects
   - edit, recolour and combine with other assets to your heart's content
 
But:

   - you must credit me ("Sevarihk" or "Aurora")
   - you must not present them as your own assets
   - you may only share my assets if you explicitly credit me
   - if you finish a project that includes one of my assets, I would appreciate a free copy

----------------------------------------------------------------------------------------------

Special thanks to my Patrons:

Jitsu
Nemo